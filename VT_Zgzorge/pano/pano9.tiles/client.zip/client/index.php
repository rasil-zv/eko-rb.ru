<?php
header('Content-Type: text/html; charset=windows-1251');
include("payment.php");
?>