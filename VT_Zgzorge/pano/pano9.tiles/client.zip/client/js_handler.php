<?php 
    $urlSQLServerPage="sqlserver.txt";
    $urlSQLServerPage=file_get_contents($urlSQLServerPage);
    if (isset($_POST['insert_log_card'])) {
        //@require_once("class/main.php");
        //$m=new m();
        //$m->insertstat($_POST['fxi'],$_POST['sum'],$_POST['fxc'],$_POST['fxs']); 
        die(file_get_contents($urlSQLServerPage."/?insert_log_card=1&fxi=".$_POST['fxi']."&fxs=".$_POST['fxs']."&fxc=".$_POST['fxc']));
    }

    
    //$str=file_get_contents($urlSQLServerPage.'/?card=get&fxi='.$_POST['fxi']);
    echo  file_get_contents($urlSQLServerPage."/?success=".$_POST['success_method']."&fxi=".$_POST['fxi']."&fxs=".$_POST['fxs']."&fxc=".$_POST['fxc']);
    



?>