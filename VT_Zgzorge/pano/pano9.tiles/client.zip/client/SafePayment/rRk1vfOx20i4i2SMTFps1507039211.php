<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/d2f483756552479289be82b04b877085" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUstu2kAU/RXL+zIP2xjQZSIIodAqKQ8DaneOPQWLYDtjOyVZ5bHMR+QXoqjZVGq/YfxHnXGgNJvRPefeOfcJR9vNhXHFRRYlcdskNWwaPA6SMIqXbXPm9T80zCMG3kpw3pvyoBCcwSnPMn/JjShsm6POhF+2FuGX9cC6bqx/jMeuaPTHN98yvDQZVG4GuwRM6dcooD1USiJY+XHOwA8uu8MzZmPqYBfQDsKGi2GPYYzrmFBqY9uiWAm80RD7G86OO5Me1Y8xmnY7Z59rkxmgygNBUsS5uGZ12wK0B1CIC7bK87SFUJqd+/G6JgpAmgV0KGhUaCtTKtsoZKKIJ8FJMpiff4xQ/+pm6nxPFqv5ySwdtwHpCAj9nDOKiUswtgxitxzaIg6gigd/o9MzYqleVHtvCFKdpPPO9T8Fat5CrWPfwR4B36ZJzFWEmsU/G0KeBUw+ydfyVr7KF/lH/jTKO0P+ks/lbXlfPhryt3w+4AdVnP4C6NDs8UDvIsjVeAluUuziuoPDpdedb63T3BsNv35yvYWvN1QF6VIiNVXSxM2qFg0AaRm0Wz7a3Yuy3t3RX6Um3cs=">
<input name="MD" type="hidden" value="253694796-5B90BA55A03C4E5C">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
