<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/6f2fa1bcaba847178d66879dd5b2a601" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1u2kAQfhXL16rs2BgMaNiI4ETQJqlDgLS5VM56BU7BmF27JTmlybEP0VeIquZSqX2G9Rt1l5+SXqz5ZsbffN/M4sFqPrM+cyGTRdq2nQrYFk/ZIk7SSdseDY9fN+wDisOp4Dy44KwQnOIplzKacCuJ23bYGfBl65LVj0J5J0+D6+XHyegduwnH3S82xXWZ4nYA1fwVF8kOaibBplGaU4zY8rB/Rj1wa+Aj2UKcc9EPKADUwXFdD7yqC5pgk8Y0mnPa7QwC13ys8OKwc/a2MhghWVeQLYo0F7e07lWR7AAWYkaneZ61CMnkdZR+qogCicki2QsKCxNJzbJKYnp83q3WrqbL0fur/OhWvBqfxFnx4c6X4XkbienAOMo5dcHxoek2LcdvVb1WzUOyzmM0N+O1PwDtbgMwMzM6LysvM6i3LfQxdvp3CPkqW6Rcd+hN/Isx5pJR9V09l/fqWf1Qf9RPq/xqqV/qqbwvH8pvlvqtnvb4UUszvyDZW+32zCVYrpfraBvgQ70Gs5txo1dMesOTyzeBXPUbxsGmyUhJ9E6dJjTXWgxAYmjI9vRk+1p09N8r+gvaLt2V">
<input name="MD" type="hidden" value="252486638-A4643E9E43B38152">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
