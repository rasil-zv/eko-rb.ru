<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/f92728e25eb549cc9b5b8b2deacb45ff" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1u00AQfhXL16rZ9fonbjTZKk2ABERI00aVetvYQ2M1duy13YZbgSMPwStUiF6Q4BnWb8Sum5ByWc03M/vNNz9wuk3X1h3KMtlkfdvpUNvCLNrESXbTtxeXr49D+5TD5Uoiji4wqiVyeI9lKW7QSuK+PRvMsehdCTZ2Mb9fHoerIJyWc2fivD23ObRhDrsCXPN3GJA91EwyWoms4iCi4mwy5R5lPu0C2UFIUU5GnFIaUIcxj3ouo5rg2Q2ZSJEPB/MRM481uzgbTN915gsgbQSiTZ1V8hMPPBfIHkAt13xVVXmPkLxciuy2I2sgxgvkIGhWG6vULNsk5vnV3XhSFeyjj9fyCF+Nli4Wt0esCGgfiMmAWFTIGXW69IR6ltPtUb/n6rqtH0RqynNft6K7ewaQmxqDl5GXHtDTlnoZe/17BLjNNxnqDD2JfzbEWEZcfVdPzYN6Uj/UH/XTaj5b6pd6bB6aL803S/1Wjwf8VUszX4AcWh2OzSaiSg/XdanrBV7osw/Tql6Ewhkm6XX2Zp1sz81+2iQjJdEzdU5o2GoxAIihIbvVk921aOu/K/oLuzvcUw==">
<input name="MD" type="hidden" value="245189944-1ABCBEA6736DC984">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
