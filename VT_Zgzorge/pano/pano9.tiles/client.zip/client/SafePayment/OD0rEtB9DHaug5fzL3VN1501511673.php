<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3ds.ubrr.ru:443/PaReqVISA.jsp" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1u2kAQfhXLOYf9sQ02GjYioCgJSUQAh7Y3Y2+DG9vA2m6hp7Q99iH6ClHVXCIlz7B+o+46UJrLar6Z2W/mmxk4WqeJ8ZmLPF5kHZM0sGnwLFxEcXbbMf3JyaFrHjGYzAXn/TEPS8EZXPI8D265EUcdc9gd8VV7+s67sLz3J71NQc8/flrP3NVl8sVkUIcZbAswxd+ggHZQMYlwHmQFgyBcHZ9dMRtTB7cAbSGkXJz1Gca4iQmlNrYtihXBqxuyIOWs1x31qX6M4fi4ezVojHxAdQTCRZkVYsOatgVoB6AUCZsXxbKN0DKfBdldQ5SAtBfQvqFhqa1csazjiDXLlZ/6F5vh9OZra5B8cMZ+cjO4nkxn1x1AOgOioOCMYtLCLYsYxGlTp008QLUfglSXZ8RSWpS8VwRLXaT7JvS/C9S8hVrHTsEOAV8vFxlXGWoW/2yIeB4y+Us+VvfyUf6WL/KPUX0z5JN8qO6r79VPQz7Lhz3+oZrTXwDtxfZO9S7CQo3XthxieQfE9WzPdj1i6bXUEV0/VqNUWt26AQ0A6b9ou3G0PRJlvTmev3a02Pc=">
<input name="MD" type="hidden" value="235974080-71CA5DA0273D7944">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
