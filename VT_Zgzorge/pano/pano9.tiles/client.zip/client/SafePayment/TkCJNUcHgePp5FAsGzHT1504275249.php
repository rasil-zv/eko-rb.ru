<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/97abc071d6c74bd09afc1ca1a7f46f3e" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1u2kAQfhXL1yrs2l4MQcNGTkgEJVBioLS9VK69gAvYZm0n0FPSHvsQfYUoSi6R2mdYv1F3HSjpZTXfzOw33/zAyWa11K4ZT8M4aupGBesai/w4CKNZUx+PLo7q+gmF0Zwz1hoyP+eMQo+lqTdjWhg09YHjsnVj4i2369nkcnm+/jx9+55YX9sxn+kUyjCFXQEq+SsmoD2UTNyfe1FGwfPXp50+Jdis4hqgHYQV450WxRjb2DBNgollYknw4obIWzF65rgtUz3aYHjq9LsVdwyojIAf51HGt9QmFqA9gJwv6TzLkgZCSfrFixYVngNSXkAHQYNcWalk2YQBdd2ry2rn3c1o0XeGk48X+LyH7Q9vFkN73ASkMiDwMkZNbNTwMTY0gzSI3VBaSz94K1Ve9oex7O4FQKJqOK8jrz0gp83lMvb69wjYJokjJjMk+z8bApb6VPwST8WteBIP4o941Io7TTyL++K2+F781MRvcX/AP6Q09QXQodWzttqEn8nhWha2iE3q1drNaGp1ybb3LQim7eRT17HUfsokJSWUMzWOcb3UogAgRYN2q0e7a5HWf1f0F4563J0=">
<input name="MD" type="hidden" value="244425573-96DFBDA8773F2379">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
