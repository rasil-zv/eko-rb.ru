<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/7098725c6a1b43de84fdd9fe43afe05b" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUkty00AQvYpKWwpP6+vY1Z6UYodg7ARZsUOxlEdDrCL6RJ9gvAqw5BBcIUWRDVVwhtGNMqPYcbKZ6tfd8/r1Bw/XyZV2w4syztKBbnRA13jKsihOLwf6Yv7m9YF+SHG+KjgfnXNWF5ziKS/L8JJrcTTQfS/g1/0P7GZxunZtnllf/JCXm+TTxWamU2zDFLcFqOTvmEh2UDIVbBWmFcWQXR+Nz6gNpgNdJFuICS/GIwoALhimaYNtmSAJHt2YhgmnQy8YmerR/PMj72zSCRZI2giyrE6r4it1bQvJDmBdXNFVVeV9QvJyGaafO0WNRHmR7AX5tbJKybKOIzpzJs6ruD4Jpuxk8z4P/ANrOZ7OITK8ARKVgVFYcWqC0YWe2dUMt2/1+oaDpPVjmKjysj8A2d0jwFzV8J5HnntQTruQy9jp3yHk6zxLucyQk3iyMeIlo+KXuG9uxb34Lf6LP1rzTRN/xV1z23xvfmrin7jb4x9SmvqCZN/q8K3aBKvkcA3ZBnTBdWAGk+GUsXfj4+PF0nPqj57aT5ukpMRypkYPeq0WBZAoGrJdPdlei7ReXNED53fcRw==">
<input name="MD" type="hidden" value="251803947-8A4A34416EFBCFEE">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
