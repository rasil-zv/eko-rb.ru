<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/535b195c00cf401fa66e7c4a779efa6a" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUktO40AQvYrl7WjS7Q9JHFUamWQQEAgmIURZjRq7FZtx7NC2kcOKz5JDcAU0GjYjwRnaN6LbJBNm06pXVf3q1Qd2y0Ws3TCeRWnS1Y0G1jWW+GkQJfOuPjnf/97Wdwmch5yx/pj5BWcETliW0TnToqCre+6IXXemNI7CMy+b/pzNLq8uSpo5ZTHXCdRhAusCRPI3TEAbKJm4H9IkJ0D9673DIbGxuYNbgNYQFowf9gnGuIkN07SxbZlYEny6IaELRnruqG+qR/PGe+5w0BhNANUR8NMiyfmKNG0L0AZAwWMS5vmyg9Ayu6TJrwYvACkvoK0gr1BWJlnKKCDHfjxM+1ffxsw9WsXBYHha9FbhkTnYn3UBqQwIaM6IiY0WdrChGVbHanWwA6j2A12o8rI/jGV3nwCWqob7NfLVA3LaXC5jo3+DgJXLNGEyQ07inw0By3winsVrdSdexW/xLv5o1b0m/oqX6q56qJ408SZetvhRSlNfAG1b7R2oTfi5HK5lYctu2u2dZnzjTHqeNw3PTnNm39o/DtR+6iQlJZIzNRzcrrUoAEjRoPXq0fpapPXfFX0Ay2/d+g==">
<input name="MD" type="hidden" value="244405408-EE4777E441CCB90D">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
