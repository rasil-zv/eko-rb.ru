<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/71a1d17cc3b44ba7a0f0340eadd19cd5" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUktS20AQvYpK+3g+kuXY1R5KtnAMFMIl7FCwU6QBy1gfRhJRWJFkmUPkClQqbFKVnGF8o8wIOw6bqX7dPa9ff+CgSdfGPRdlkmdDk3SwafAsyuMkuxmai/nkzVvzgMF8KTj3znlUC87glJdleMONJB6aMzfgd4OL+MyZH0/o9buHj9Opv0pOrJK7JoM2zGBbgCn+DgW0g4pJRMswqxiE0d3oyGc2pl3cA7SFkHJx5DGMsYMJpTa2LYoVwYsbsjDlbOwGHtWPMTsfuf5JJ1gAaiMQ5XVWiU/MsS1AOwC1WLNlVRUDhIryQ5jddkQNSHsB7QXNam2ViqVJYuaNFlfEvXp/Zq/z8trjQVCQy3uLr44Ph4B0BsRhxRnFpEcwtgziDKgz6CqtrR/CVJdnxFK9qPZeEBS6iPsq9L8L1LyFWseugx0C3hR5xlWG4v9nQ8zLiMnv8nnzKJ/lD/lH/jQ2nw35Sz5tHjdfNt8M+Vs+7fFXJU5/AbRvdjzVu4gqNV6C+xT3sNPFq8MLP7j0Jil+sG9FM/YbvaE2SUtJ1FRJH/dbLRoA0jRou3y0vRdlvbqjvy7d3Qg=">
<input name="MD" type="hidden" value="253727420-A033E40B7D8A2034">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
