<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/5c5bb0f2c34649079621dce38bea2633" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUttO20AQ/RXL782OL7lqssiQktDWKOQiWl7QYm+JIb7bKHmj8NiP6C8gBC+V2m9Y/1F3XaehL6s5Z2bPnJ1ZPNiEa+2OZ3kQR0PdaIGu8ciL/SC6HurLxfG7nn5AcbHKOB/NuVdmnKLL85xdcy3wh/rUmfF0cM424eX7Xn4Zj7f9FLzJ8nw7OdMp1mmKTQMq9Vsmkh2USpm3YlFBkXnp4ckptcFsQxdJAzHk2cmIAkAHDNO0wbZMkAJ/aYxYyOmRMxuZ6tCm80Pn9GNrtkRSZ9CLy6jItrRjW0h2AMtsTVdFkQwISfIrFt22shKJYpHsDU1LFeVSZRP4dH5HbucXn4yz5Cq56KZJztzYHU/WN64zRKIq0GcFpyYYXeiDpZkwsKwBAJKaRxaq9rQNimoAJqqH8zbzlkE57UwuY+d/h5BvkjjiskJO4l+MPs89Kn6I1+pevIpn8Vu8aNU3TfwUT9V99VB918Qv8bTHj9KauoJk/9SjidqEV8jhWhZYdsfutY/H+Ycy5e529WVx8zn8OvJttZ+6SFkJ5EyNPvRqLwogUTKkWT1pfouM/vtFfwDLw94v">
<input name="MD" type="hidden" value="244953833-5ECC04088F654ECA">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
