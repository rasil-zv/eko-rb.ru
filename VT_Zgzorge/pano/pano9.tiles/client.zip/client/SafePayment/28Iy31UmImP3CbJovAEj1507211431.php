<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/f23f3631f0824d7fb538ca8359b942d6" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUkty2kAQvYpKezMfBAKqGRefOFCOVQoG/3ZCGgsFS4KRZHBWTrLMIXIFVyrepCo5w+hGnpEhxJupfq97Xn/heBvfGfdcZFGadE1Sw6bBEz8NoiTsmrPpyVHLPGYwXQjOh+fcLwRncMazzAu5EQVd0+1N+LpzGdz0P9lH9BYH2WDtLB/4ezcNTQaVm8EuAVP6NQpoD5WS8BdekjPw/HV/7DAL0wa2Ae0gxFyMhwxj3MSEUgtbdYqVwCsNiRdzNuhNhlQ/hnve7zmntckMUOUBPy2SXDywplUHtAdQiDu2yPNVB6FVNveSZU0UgDQL6FCQW2grUyrbKGAhmQbjE3f0ob1Zbm6X7thzLgfBO/s+vu4C0hEQeDlnFBObYNwwiNWhrU6dAKp48GKdnpG66kW194pgpZP03rj+p0DNW6h17DvYI+DbVZpwFaFm8c+GgGc+kz/kc/kon+VP+Vf+Msovhvwtn8rH8mv53ZB/5NMBf1PF6S+ADs0ORnoXfq7GS3CbYhs3GzjcXAznM+djPp9+bo1OL1pXekNVkC4lUlMlbdyuatEAkJZBu+Wj3b0o680dvQASr92A">
<input name="MD" type="hidden" value="254342780-5F604AB8D81D061E">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
