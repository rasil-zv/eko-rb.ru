<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/afcdf503f1c244c8859590caed17f7f6" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1O20AQfhXL14rsevNjJ5oscrACiCRKYqJKvVRmvU2sxHZY2+Byou2Rh+AVUFUuSPAM6zfqrkkaelnNNzP7zTc/cFzGG+OGiyxKk75pNbBp8ISlYZQs++bicnjkmMcULleCc8/nrBCcwphnWbDkRhT2zak759e9z+x2/TU9c7y2GHXuSDm+uljezEwKdZjCrgBV/A0CaA8Vk2CrIMkpBOx6cD6hLUza2Aa0gxBzce5RjHEHW4S0cKtJsCJ4d0MSxJyeuHOP6MeY+gN3ctGYLwDVEWBpkeTiO+20moD2AAqxoas83/YQ2mZXQbJuiAKQ9gI6CJoW2soUSxmFdD2bnPquPxyh8R3fkHziflo5sy8sCFkfkM6AMMg5JdiycZfYBiE90uy1HUC1H4JYl1f9Yay6ewew1TXcj5GPHlDTFmoZe/17BLzcpglXGWoS/2wIecaofJTP1b18lr/lm/xjVD8M+SKfqvvqZ/VgyFf5dMC/lDT9BdCh1ZMzvQmWq+Faqg1s404bT1m5mA+7tnM68uJBOfK/6f3USVpKpGZqdXG31qIBIE2DdqtHu2tR1n9X9BeSEdyZ">
<input name="MD" type="hidden" value="251883228-8A98B4B7E0E336D2">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
