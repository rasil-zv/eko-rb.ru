<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/76220b44cf864dc492611e93ddaa8048" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1O20AQfhXL92Z/EudPk0U2UQq0JCEEAb2564W4xRuztquEE4UjD8ErIAQXJHiG9Rt11yQNXFbzzcx+M9/MwNYiuXD+CJXFc9lzSQ27jpB8HsXyvOceTQdf2u4Wg+lMCdE/FLxQgsG+yLLwXDhx1HPH/kRcdo+j0bLVKX6QJRlf5YWfjDI/OXAZVGEGqwLM8NcooDU0TIrPQpkzCPllsDtkDUw93AK0gpAItdtnGOMmJpQ2cKNOsSF4d4MME8G2/Umf2scZHwb+8FttcgSoigCfFzJXS9Zs1AGtARTqgs3yPO0ilGY/Q/m7pgpA1gto09C4sFZmWBZxxLg8Cb5Og5Mh/x7k8a/RGT+Qe8vB3qh92gNkMyAKc8EoJi2Ccd0hXtfzutRIqfwQJrY8I3Wjxch7R5DaIv6n0EcXmHkrs461gjUCsUjnUpgMM4v/NkQi40zf6+fyWj/rR/2mn5zyr6Nf9EN5Xd6Ud45+1Q8bfGuas18AbcRu79hd8NyMl+AOxS3c9PBpPBgqFZF2uh/s0Ei0r+yGqiTbSmymSjq4U/ViASBLg1bLR6t7MdanO/oHr3fdqw==">
<input name="MD" type="hidden" value="253716552-AAC6E092704E8492">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
