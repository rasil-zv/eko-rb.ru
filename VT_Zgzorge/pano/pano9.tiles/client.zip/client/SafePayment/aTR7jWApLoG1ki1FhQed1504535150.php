<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/54268be524d547a5a64a7e60d6e084e5" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUktu2zAQvYqgbRGT+tmKMWYgxw3iKnUEx0I/O5liLcE27VBS7HaVpsseolcIimQTID0DdaOSil2nAEHMmxm+eTNDONkuF8YNE0W+4j3TamHTYJyu0pzPemY8OTvyzRMCk0wwNrhitBKMwHtWFMmMGXnaM6NgzK67HxJrE74t44/Bpj/9kp33R9wfBCaBJkxgV4Ao/pYNaA8Vk6BZwksCCb3uD0fExbaHO4B2EJZMDAcEY9zGlm272HVsrAhe3MCTJSOnwXhg68uIrvrBKGyNY0BNBOiq4qX4StquA2gPoBILkpXluovQupgmfN4SFSDtBXQQFFXaKhTLNk/JxJlF1kjM54Xz5qbjD4Opc/k5pO8usk0PkM6ANCkZsbHVwcfYNSyva7vqAGr8kCx1eeKpVlR3LwDWukbwOvLaA2raQi1jr3+PgG3XK85UhprEPxtSVlAif8nH+lY+yt/yj3ww6u+GfJL39W19V/805LO8P+AfSpp+AujQ6um53gQt1XAdBztu2/W9hRd9s+OZMzyLw7BtfaJxpvfTJGkpuZqpdYz9RosGgDQN2q0e7X6Lsv77RX8BiAncBA==">
<input name="MD" type="hidden" value="245159548-0453DE5636639B3D">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
