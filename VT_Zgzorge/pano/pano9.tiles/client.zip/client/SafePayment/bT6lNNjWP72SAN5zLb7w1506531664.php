<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/24cf9c194add4adeaa2f64da71ad9974" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1y2jAQfhWP70VrYTAwizImTGgakjr8lFwdWwU3IINsJ+SWtsc8RF4h02kunWmfQX6jSg6U9KLZb3f17bc/eLRdLa1bLrMkFV3bqYFtcRGlcSLmXXs6OXnXso8YThaS8/6YR4XkDM95loVzbiVx1w78Ed90ZtHtl5vwbt67W07o7OOmNZT+zLcZVmGGuwJM89cokj3UTDJahCJnGEab3ukFc4E2wEOyg7ji8rTPAKAJDqUuuHUKmuDVjSJccXbsj/rUPFYw7vkXZ7XRFEkVwSgtRC7vWdOtI9kDLOSSLfJ83SFknV2H4qYmCyTGi+QgKCiMlWmWbRKzcZu7y+kAws9p8Gk4oC0pTj7MhvXoHrpITAbGYc4ZBceDNvUsx+u4bsdtI6n8GK5Med0fgO7uFeDa1PDfRt56UE9b6mXs9e8R8u06FVxn6En8szHmWcTUk3opH9SL+qH+qJ9W+dVSv9Rz+VB+Kx8t9Vs9H/B3Lc18QXJo9fi92USU6+E6ug3woNmAqzP/yim83mVjcCmu08YoMPupkoyURM/UaUO70mIAEkNDdqsnu2vR1n9X9Besn9xf">
<input name="MD" type="hidden" value="251825354-D433322233C82036">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
