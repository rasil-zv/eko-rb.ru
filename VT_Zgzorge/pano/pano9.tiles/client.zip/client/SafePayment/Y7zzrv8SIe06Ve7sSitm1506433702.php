<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/59a4508a3680440f915653073539ed9e" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUttuGjEQ/ZXVvhd7jRcWNDjiIlrUFhEIidI3s2stLuyFvUQkT2nz2I/oL0RV81Kp+QbvH8XeQElfrDkz4zNnLnC2j7bWjchymcQ922lg2xKxnwQyDnv28mL8zrPPGFysMyFGC+GXmWDwWeQ5D4Ulg54968/Frnvlp/xWevvSXTU30SVfhis+CW0GdZjBoQDT/A0C6Ag1U+aveVww4P5uMJkyiomL24AOECKRTUYMY9zCDiEU0ybBmuDVDTGPBBv25yNiHmu2GPSnHxvzJaA6An5SxkV2y1q0CegIoMy2bF0UaRehNF/xeNPISkDGC+gkaFYaK9csexmw6UIm4Vj6s/hu3WoPxl9v5Oaa5tEuTXqATAYEvBCMYKeNO6RlOc0u9bquB6j2A49Med0fxrq7VwCpqdF/G3nrAT3tTC/jqP+IQOzTJBY6Q0/inw2ByH2mfqqn6l49qV/qWf22qm+W+qMeq/vqe/XDUn/V4wk/aGnmC6BTq8MPZhN+oYdLMKVuu+MSupt8oufb91+oe4VduV15Q7OfOslIkXqmTgd3ai0GADI06LB6dLgWbf13RS8JQt3/">
<input name="MD" type="hidden" value="251420749-3F608411488978DF">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
