<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/c62ba195ed0e4ff383e7b3d8d32dd37e" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUttu2kAQ/RXLr1XZ9dpcgoaNDCYqQkGUS5rmzbVHwUmwYW2DeUvax35EfiGKmpdK7Tes/yi7DpT0ZTVnZvbMmQucFss7Y4MijZK4Y1o1ahoYB0kYxdcdcz47+9gyTznMFgLRm2KQC+RwjmnqX6MRhR1z7E5w3f7iF4P+16TPLnG+vRkmu6y/3mxNDlWYw74AV/w1BuQAFZMIFn6ccfCDdXcw4g5lddoEsoewRDHwOKW0QS3GHOrYjCqCNzfE/hJ5z514TD/GeNp1R8PaZA6kikCQ5HEmdrzh2EAOAHJxxxdZtmoTskq/+fFtTeRAtBfIUdA411aqWIoo5Fcs7oW4mY0vPt/0iuLsw/A8dRkbND3aAaIzIPQz5IxaTXpCbcNqtZnVpnUglR/8pS7P66oV1d0bgJWu4b6PvPeAmrZQyzjoPyDAYpXEqDLUJP7ZEGIacPkoX8p7+SKf5V/5yygfDPlbPpX35ffypyH/yKcj/qGk6S9Ajq32PulNBJkarm1T22k4rbq1E3hx1Z9v17fBdOh1J8zS+6mStJRIzdQ6oa1KiwZANA3Zr57sr0VZ/13RK5fg3UU=">
<input name="MD" type="hidden" value="244931081-5CFCB5544F95AB98">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
