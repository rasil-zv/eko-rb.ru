<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/386f0d73024e47bfb786546b1ed388c9" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1u00AQfhXLd7Jjx4nraLJVEgvVIi0mjUXFbbFXsWn8k7VdBU4FjjwEr1AhekGCZ1i/EbtuQuhlNd/M7Dcz3wye7/OtccdFnZXF1LQGYBq8iMskKzZTM1q/fHFmnlNcp4Jz/5rHreAUL3ldsw03smRqhrMV303eJjd3onkdRLt3bxq3Wn4Kqkt3Y1LswxQPBajiH9hIjlAxiThlRUORxbt5cEUdsEfgIjlAzLkIfAoAY7Bs2wFnaIMieHJjwXJOF7OVb+vHCK/ns6tXg1WEpI9gXLZFIz7SsTNEcgTYii1Nm6aaEFLV71lxOxAtEu1FcmoobLVVK5Z9ltB5GaXcv8jrcMt2N37a3o6W+3quVIimSHQGJqzh1AbLtQBGBpxNht7EAiS9H1muy1NrqGZR4z0hrHSR2bPQ/y5Uegu1juMER4R8X5UFVxlKi382JryOqfwuH7t7+Sh/yD/yp9F9NuQv+dDdd1+6b4b8LR9O+KtqTn9Bchp2caF3ETdKXgs8G1wYjyBslv46WC8/OHYa+ox5C72hPkm3kilVLQ+8vhcNkGgaclg+OdyLsp7d0V/6/t44">
<input name="MD" type="hidden" value="254219273-093D355A44BD576E">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
