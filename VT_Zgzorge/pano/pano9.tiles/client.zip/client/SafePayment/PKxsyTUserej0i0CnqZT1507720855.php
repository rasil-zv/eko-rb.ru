<center>
<hr WIDTH="100%">
</center>
<center><font size=4>
<p>Sorry, due to technical fault your request cannot be processed
</p>
<p>
Error message: Error in merchant terminal field
</p>
<p>Please try once again or visit us later
 or choose another means of payment.
</p>
</font>
</center>
<center>
<hr WIDTH="100%">
</center>