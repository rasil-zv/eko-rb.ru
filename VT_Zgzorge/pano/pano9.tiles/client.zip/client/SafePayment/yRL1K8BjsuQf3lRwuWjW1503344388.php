<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/6e5d583293604edb9a9309c759a16bb7" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1y2jAQfhWP70WybMAwizJOGJq0E0JwGDLcjK3GTkHYkp2QW9Ie+xB9hUynuXSmfQb5jSo5UNKLZr/d1bff/sDRdr2y7piQ2YYPbKeFbYvxeJNk/GZgz65G73z7iMJVKhgbhiyuBKNwzqSMbpiVJQN7EkxZ0Z8vZHf8CV/M5oLn6W1070+KTmBTaMIUdgWo5m8RQHuomUScRrykEMXF8dmYepi0cRfQDsKaibMhxRh3sEOIhz2XYE3w6gYerRk9CaZDYh5rEh4H44+t6QxQE4F4U/FSPNCO5wLaA6jEiqZlmfcRyuUy4p9bogJkvIAOgiaVsaRm2WYJvY5PH8hi6V58WBaX52kR3vvjLGsv5PvZAJDJgCQqGSXY6WKfOJbT67e7fc8B1PghWpvyuj+MdXevAHJTI3gbeesBPW2hl7HXv0fAtvmGM52hJ/HPhoTJmKrv6qV+VC/qh/qjflr1k6V+qef6sf5Sf7PUb/V8wF+1NPMF0KHVk1OzibjUwyUO6Xl+28fED0ZZeHc7l6PraBVeuqVr9tMkGSmZnqnTw36jxQBAhgbtVo9216Kt/67oL0gg3WY=">
<input name="MD" type="hidden" value="241625005-2D023F5EF2CDDDD5">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
