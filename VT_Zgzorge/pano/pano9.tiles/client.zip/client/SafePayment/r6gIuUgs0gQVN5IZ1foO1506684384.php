<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/71282545a66d4797b1b0313613c5e84b" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1S2zAQfhWP741k2UlIZiNGJKGhpUnGJIWeGGOrsYHYiSyD2xNtj32IvgLTKRdm6DPIb1TJJIReNPvtrr799gf2y+W1dcNFnmRpz3Ya2LZ4GmZRki569nx2+GbP3qcwiwXngxMeFoJT+MDzPFhwK4l69pT5fN09DT157vr+4enZ+dXlaD1kn971FzaFOkxhU4Bq/gYBtIWaSYRxkEoKQbg+OBpTD5MmbgPaQFhycTSgGOMWdgjxsOcSrAme3ZAGS077zB8Q81jTkwM2ft/w54DqCIRZkUrxhbY8F9AWQCGuaSzlqovQKr8I0quGKAAZL6CdoGlhrFyzlElE2fByEX+ejNjXMp472ZqN37okmuwN2vMeIJMBUSA5Jdhp4w7pWI7TJa1uswmo9kOwNOV1fxjr7p4BrEwN9jry2gN62kIvY6t/i4CXqyzlOkNP4sWGiOchVb/UQ3WnHtRv9Vf9sapvlnpU99Vd9b36aakndb/DP7Q08wXQrtX+yGwilHq4jm4Dt3Gric9uZ1KWNyP20R32J97t8dDsp04yUhI9U6eDO7UWAwAZGrRZPdpci7b+u6J/5/Pcig==">
<input name="MD" type="hidden" value="252355168-85D20DD2F19D7CA2">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
