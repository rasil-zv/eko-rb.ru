<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/b602cc0e5065472990df2d64f8481dc0" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1u00AQfhXLV0T2J05SR5OtnITQULVEdkN7NfaSWNSb9dqOUk4FjjwEr1AhekGCZ1i/EbtuQsplNd/M7Dff/MDpLr91tlyV2UaMXNLBrsNFskkzsRq5y6vZyxP3lMHVWnE+jXhSK87ggpdlvOJOlo7cRRDyYnidyNCfziP/Q1RcnL3z5JtJ/TpwGbRhBvsCzPB3KKADNEwqWceiYhAnxXh+yTxMe3gAaA8h52o+ZRjjPiaUetjrUmwIntwg4pyzSRBOqX2cRTQOLs874RJQG4FkU4tK3bG+1wV0AFCrW7auKjlESJbvY/Gxo2pA1gvoKGhRW6s0LLssZUhEZCG7AbpZnb8Yv03psppN0k+zsjgZAbIZkMYVZxSTAfZp3yHdISFD0gfU+iHObXnTH8amuycA0tYInkeee8BMW5llHPQfEPCd3AhuMswk/tmQ8jJh+rt+bO71o/6h/+ifTvPZ0b/0Q3PffGm+Ofq3fjjir0aa/QLo2OrkzG4iqcxwKfa83sDvUc+/ebXNe9siXCs5r+W4vLb7aZOslMzMlPjYb7VYAMjSoP3q0f5ajPXfFf0FJo7cnA==">
<input name="MD" type="hidden" value="251407971-A800CBD08FE12564">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
