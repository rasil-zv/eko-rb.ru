<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/43f42d0b084c4136b52de6bf8a3a5ed2" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1u2kAQfhXL97JjG0OMho1MLJQQlVgQiHp07W2wwD+s7WBySttjH6KvEFXNpVL7DOs36q4DJb2s5puZ/eabHzyvk432wHgRZ+lQNzqgaywNsyhO74f64nb87kw/p3i74ox5cxZWnFF8z4oiuGdaHA11352x7eAufLC2TrKyLovporf/tByfjW92OsU2TPFQgEr+jonkCCUTD1dBWlIMwu3oakq7YNrQR3KAmDB+5VEA6IFhml3oWiZIglc3pkHC6IU780z1aP585E6vO7MFkjaCYValJd/TXtdCcgRY8Q1dlWU+ICQvPgbpusMrJMqL5CTIr5RVSJY6jqi3mcT+42S+dJZLZ7c27rLajpJ9nV6vh0hUBkZByagJRh8cs68ZzsCAgWUjaf0YJKq87A9AdvcKMFc13LeRtx6U0+ZyGUf9R4SszrOUyQw5iX82RqwIqfguXpon8SJ+iD/ip9Z81sQv8dw8NV+ab5r4LZ5P+KuUpr4gObV6cak2EZZyuIZsA/rQs8Gu8seJy8Hb+bvR/AOMbLWfNklJieVMDQecVosCSBQNOayeHK5FWv9d0V84Kd1T">
<input name="MD" type="hidden" value="251853278-6736A0302754A1E7">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
