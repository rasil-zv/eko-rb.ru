<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/745064c1315c48f395d45d18eada76f1" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1O20AQfhXL92Z/YhInmixyEqrSlmA5RBQulbFXiVXHdtbrEHqi7ZGH4BUQgkul8gzrN+quSRp6Wc03M/vNNz9wuFmm1pqLMsmzgU1a2LZ4FuVxks0H9uzs/TvXPmRwthCcj6c8qgRncMLLMpxzK4kHtu8FfNU/vywvruPZ90VwOpT+enxB5Ne1ZzNowgy2BZjmb1FAO6iZRLQIM8kgjFbD4wlzMD3AXUBbCEsujscMY9zBhFIHO22KNcGrG7JwydnIC8bUPJY/HXqTT61gBqiJQJRXmRQ3rOO0Ae0AVCJlCymLPkJFeRVm31qiAmS8gPaC/MpYpWbZJDGbrj6HR+n85Iak7kROTi9neUJEIX3naADIZEAcSs4oJl3sUmKRbr+N+w4B1PghXJryuj+MdXevAApTw3sbeesBPW2hl7HTv0PAN0WecZ2hJ/HPhpiXEVP36rm+Vc/qUb2oJ6v+Yanf6qG+rX/Wd5b6ox72+JeWZr4A2rc6+mA2EUk9XEpoz3EPXEyrlex1OlcfvySpX4g88EZmP02SkZLomZIedhstBgAyNGi7erS9Fm39d0V/AUTN3hY=">
<input name="MD" type="hidden" value="241592876-585625EB7E6C49F1">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
