<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/6f1c1db1b26e482fb7e2d68691a1d7be" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUs1u2kAQfhXL1yrs2Bgco2EjJygtIlAXEqVXY6/AIv5hbSc2p6Q99iH6ClHVXCq1z7B+o+46UNLLar6Z2W+++cGzKr7T7hnPozQZ6kYHdI0lQRpGyWqo31xfnpzqZxSv15yx0YIFJWcUpyzP/RXTonCoe+6cbQe3QZFNTmrrKhrXy8l28TmbGtUnnWIbprgvQCV/x0RygJKJB2s/KSj6wfZ8PKMWmD2wkewhxoyPRxQA+mCYpgVW1wRJ8OrGxI8ZvXDnI1M9mrc4d2eTzvwGSRvBIC2Tgte0b3WRHACW/I6uiyIbEJLlSz/ZdHiJRHmRHAV5pbJyyVJFId1AWjEvqlZO/THbLWc77/b+avfuPbDNEInKwNAvGDXBsMExbQ2cAZiDbg9J60c/VuVlfwCyu1eAmarhvo289aCcNpfLOOg/IGRVliZMZshJ/LMxZHlAxXfx0jyKF/FD/BE/teZJE7/Ec/PYfGm+aeK3eD7ir1Ka+oLk2OrFB7WJoJDDNWQbYEO/B6NTPrXnfte5fIjdh9pbZWo/bZKSEsmZGg44rRYFkCgasl892V+LtP67or9Lht4f">
<input name="MD" type="hidden" value="251654423-405E4912A7A67C10">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
