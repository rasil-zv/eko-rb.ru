<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML>
<HEAD>
</HEAD>
<BODY ONLOAD="javascript:OnLoadEvent();">
<FORM ACTION="https://3DSecure.qiwi.com/acs/pareq/43081261ad6445458d27c18016b1926f" METHOD="post" NAME="ThreeDform" target="_self">
<input name="PaReq" type="hidden" value="eJxVUkFu2zAQ/Iqga1GToinLNtYMlMhtHbepYScImpssMbaQSHIoKpVvaXvsI/qFoEguAZo3UD8Kqcp1eiF2Zpezw13CQZVeW7dcFEmejWyng22LZ1EeJ9lqZJ+dvnvbtw8YnK4F58GCR6XgDD7xoghX3ErikT3z5/xmeB5JuposM/f4Uk4XnvvZHxPu2wyaNIO2AdP6HQJoB7WSiNZhJhmE0c3h5IRRTFzsAWohpFxMAoYx7mGHEIppl2At8JeGLEw5O/LnATGHNVsc+ifTzvwMUJOBKC8zKbasR7uAdgBKcc3WUm6GCG2KZZhddUQJyLCA9oZmpYkKrVIlMSMrcUG/+vNleVGdV1j2ZdDdvgnGXjkZATIVEIeSM4IdDw+IZzl4iPtDjAE1PISpaa/fZ6gWwMb08F9nXjOgpy30Mnb+dwh4tckzriv0JP7FEPMiYuqXeqzv1KP6rZ7Vg1V/s9STuq/v6u/1T0v9Ufd7/ENbM1cA7Z969MFsIpJ6uART6noDl9Ci//7yy3j68bi35XkYXsWp2U9TZKwkeqbOAA8aLwYAMjKoXT1qf4uO/vtFL4wm3Lk=">
<input name="MD" type="hidden" value="251675404-0B4392CAF7340227">
<input name="TermUrl" type="hidden" value="https://3ds.payment.ru/cgi-bin/cgi_link">
</FORM>
<SCRIPT>
function OnLoadEvent () 
{
  document.forms[0].submit();
}
</SCRIPT>
</BODY>
</HTML>
